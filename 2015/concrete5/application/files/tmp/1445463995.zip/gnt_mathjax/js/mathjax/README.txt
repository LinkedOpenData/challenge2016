If you want to use MathJax directly from your local server, please download MathJax and place the content of the archive in this directory.

Once you have downloaded and installed the content of MathJax : http://www.mathjax.org/download/, you should have MathJax.js in this directory.

At that point the addon will automatically detect it and let you choose between local and CDN version

