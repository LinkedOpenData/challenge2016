List Files From Set
===================

A concrete5.7 block package to list files from a File Set

A 5.6 compatible version of the block is available in the '5.6 version' branch.
